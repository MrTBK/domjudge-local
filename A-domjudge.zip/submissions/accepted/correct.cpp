#include <bits/stdc++.h>
int main() {
    long long n, k;
    std::cin >> n >> k;
    // n(n-1)/2 <= 5e9, times k <= 1e9 -> <= 5e18 < 9.22e18. Dividing BEFORE multiplying k is what keeps it in range.
    std::cout << n * (n - 1) / 2 * k << "\n";
}